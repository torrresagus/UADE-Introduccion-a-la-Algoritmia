#Ejercicio 3:Calcular el promedio de las notas que obtiene un alumno al rendir los dos parciales. 
Nota1 = float(input("Ingresar la Nota del Primer Parcial: "))
Nota2 = float(input("Ingresar la Nota del Segundo Parcial: "))
Promedio = (Nota1 + Nota2) / 2
print("El promedio del alumno es: ", Promedio)
