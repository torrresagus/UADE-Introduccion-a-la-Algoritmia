#Ejercicio 2:Desarrollar un programa que permita ingresar dos números enteros A y B a través del teclado. 
#Imprimir su suma y su diferencia.
Numero1 = int(input("Ingresar un Numero: "))
Numero2 = int(input("Ingresar Segundo Numero: "))
print("La suma de los numeros", Numero1, "y", Numero2, " es: ", Numero1 + Numero2)
print("La diferencia de los numeros", Numero1, "y", Numero2, " es: ", Numero1 - Numero2)