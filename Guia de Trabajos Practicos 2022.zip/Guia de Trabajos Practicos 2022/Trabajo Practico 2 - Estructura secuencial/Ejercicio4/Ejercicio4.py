#Ejercicio 4:Escribir un programa que permita ingresar la edad de una persona en años y la convierta a días,
#imprimiendo el resultado. Considerar que to-dos los años tienen 365 días.
EdadAños = int(input("Ingresar la Edad en años: "))
EdadDias = EdadAños * 365
print("La Edad en Dias es: ", EdadDias)
