#Ejercicio 6:Ingresar tres números enteros, calcular su promedio y mostrarlo por pantalla.
Numero1 = int(input("Ingresar el Primer Numero: "))
Numero2 = int(input("Ingresar el Segundo Numero: "))
Numero3 = int(input("Ingresar el Tercer Numero: "))
Promedio = (Numero1 + Numero2 + Numero3) / 3
print("El promedio de los numeros", Numero1, Numero2, Numero3, " es: ", Promedio)
