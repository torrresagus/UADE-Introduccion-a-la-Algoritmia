#Ejercicio 7:Una persona invierte su capital en un banco y desea saber cuánto dinero ganará en un mes, 
#teniendo en cuenta que el banco paga 2% mensual. 
#¿Cuánto ganará en seis meses si deja su dinero invertido?

