#Ejercicio 1:Ingresar dos números enteros e indicar si son iguales o distintos.

Numero1 = int(input("Ingresar el primer numero: "))
Numero2 = int(input("Ingresar el segundo numero: "))
if Numero1 == Numero2:
    print("Los numeros", Numero1, " y ", Numero2," son iguales")
else:
    print("Los numeros", Numero1, " y ", Numero2," son distintos")

