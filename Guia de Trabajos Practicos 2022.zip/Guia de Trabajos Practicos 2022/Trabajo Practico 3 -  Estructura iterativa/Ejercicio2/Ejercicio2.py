#Ejercicio 2:Leer un número entero e imprimir un mensaje indicando si es par o impar.
Numero1 = int(input("Ingresar un Numero Entero: "))
if Numero1 % 2 == 0:
    print("El numero", Numero1, " es par!")
else:
    print("El numero", Numero1, " es impar!")
    